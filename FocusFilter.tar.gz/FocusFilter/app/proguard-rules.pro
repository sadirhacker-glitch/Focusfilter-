# Add project specific ProGuard rules here.
-keep class com.focusfilter.** { *; }
-keep class androidx.room.** { *; }
-dontwarn kotlin.**
-keepattributes *Annotation*
