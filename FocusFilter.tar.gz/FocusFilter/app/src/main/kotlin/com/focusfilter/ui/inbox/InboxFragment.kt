package com.focusfilter.ui.inbox

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.focusfilter.adapter.NotificationAdapter
import com.focusfilter.databinding.FragmentInboxBinding
import com.focusfilter.viewmodel.InboxViewModel
import com.google.android.material.dialog.MaterialAlertDialogBuilder

class InboxFragment : Fragment() {

    private var _binding: FragmentInboxBinding? = null
    private val binding get() = _binding!!
    private val vm: InboxViewModel by viewModels()
    private lateinit var adapter: NotificationAdapter

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentInboxBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupRecycler()
        setupObservers()
        setupClearAll()
    }

    private fun setupRecycler() {
        adapter = NotificationAdapter(
            onRestore = { vm.restore(it.id) },
            onDelete = { vm.delete(it.id) }
        )
        binding.recycler.layoutManager = LinearLayoutManager(requireContext())
        binding.recycler.adapter = adapter
    }

    private fun setupObservers() {
        vm.filteredNotifications.observe(viewLifecycleOwner) { list ->
            adapter.submitList(list)
            val isEmpty = list.isEmpty()
            binding.emptyState.visibility = if (isEmpty) View.VISIBLE else View.GONE
            binding.recycler.visibility = if (isEmpty) View.GONE else View.VISIBLE
            binding.btnClearAll.isEnabled = !isEmpty
        }
    }

    private fun setupClearAll() {
        binding.btnClearAll.setOnClickListener {
            MaterialAlertDialogBuilder(requireContext())
                .setTitle("Clear All")
                .setMessage("Delete all filtered notifications from the inbox?")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Clear All") { _, _ -> vm.clearAll() }
                .show()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
