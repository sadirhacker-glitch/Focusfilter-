package com.focusfilter.util

import android.content.Context
import android.content.SharedPreferences
import com.focusfilter.model.FocusModeType

class PreferencesManager(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("focusfilter_prefs", Context.MODE_PRIVATE)

    var activeModeType: String
        get() = prefs.getString(KEY_ACTIVE_MODE, FocusModeType.NONE.name) ?: FocusModeType.NONE.name
        set(value) = prefs.edit().putString(KEY_ACTIVE_MODE, value).apply()

    var isFocusEnabled: Boolean
        get() = prefs.getBoolean(KEY_FOCUS_ENABLED, false)
        set(value) = prefs.edit().putBoolean(KEY_FOCUS_ENABLED, value).apply()

    var startOnBoot: Boolean
        get() = prefs.getBoolean(KEY_START_ON_BOOT, false)
        set(value) = prefs.edit().putBoolean(KEY_START_ON_BOOT, value).apply()

    var totalFocusMinutesToday: Long
        get() = prefs.getLong(KEY_FOCUS_MINUTES, 0L)
        set(value) = prefs.edit().putLong(KEY_FOCUS_MINUTES, value).apply()

    var focusStartTimestamp: Long
        get() = prefs.getLong(KEY_FOCUS_START, 0L)
        set(value) = prefs.edit().putLong(KEY_FOCUS_START, value).apply()

    var lastResetDay: Int
        get() = prefs.getInt(KEY_LAST_RESET_DAY, -1)
        set(value) = prefs.edit().putInt(KEY_LAST_RESET_DAY, value).apply()

    companion object {
        private const val KEY_ACTIVE_MODE = "active_mode"
        private const val KEY_FOCUS_ENABLED = "focus_enabled"
        private const val KEY_START_ON_BOOT = "start_on_boot"
        private const val KEY_FOCUS_MINUTES = "focus_minutes_today"
        private const val KEY_FOCUS_START = "focus_start_ts"
        private const val KEY_LAST_RESET_DAY = "last_reset_day"
    }
}
