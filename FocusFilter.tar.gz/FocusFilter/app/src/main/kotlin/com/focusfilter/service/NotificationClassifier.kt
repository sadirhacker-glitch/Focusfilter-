package com.focusfilter.service

/**
 * Interface for classifying notification text into semantic categories.
 * All classification is done locally on-device — no data leaves the device.
 */
interface NotificationClassifier {
    /**
     * Classify the given notification text.
     * @return one of: "otp", "payment", "bank", "emergency", "spam", "promo", "social", "important", "unknown"
     */
    fun classify(notificationText: String): String
}
