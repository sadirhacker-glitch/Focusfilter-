package com.focusfilter.model

enum class FocusModeType(val displayName: String, val description: String) {
    GAMING("Gaming Mode", "Block distractions, allow essentials"),
    WORK("Work Mode", "Prioritize work apps and important alerts"),
    SLEEP("Sleep Mode", "Only emergencies will break through"),
    CUSTOM("Custom Mode", "Create your own rules and filters"),
    NONE("Focus Off", "All notifications pass through")
}
