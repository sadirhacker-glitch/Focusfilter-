package com.focusfilter.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.focusfilter.data.db.dao.FilteredNotificationDao
import com.focusfilter.data.db.dao.FocusModeDao
import com.focusfilter.data.db.dao.RuleDao
import com.focusfilter.data.db.entities.FilteredNotification
import com.focusfilter.data.db.entities.FocusMode
import com.focusfilter.data.db.entities.Rule
import com.focusfilter.model.FocusModeType
import com.focusfilter.model.NotificationAction
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [FilteredNotification::class, Rule::class, FocusMode::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun filteredNotificationDao(): FilteredNotificationDao
    abstract fun ruleDao(): RuleDao
    abstract fun focusModeDao(): FocusModeDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "focusfilter.db"
                )
                    .addCallback(object : Callback() {
                        override fun onCreate(db: SupportSQLiteDatabase) {
                            super.onCreate(db)
                            // Seed default focus modes
                            CoroutineScope(Dispatchers.IO).launch {
                                INSTANCE?.let { database ->
                                    seedDefaultModes(database.focusModeDao())
                                    seedDefaultRules(database.ruleDao())
                                }
                            }
                        }
                    })
                    .build()
                INSTANCE = instance
                instance
            }
        }

        private suspend fun seedDefaultModes(dao: FocusModeDao) {
            dao.insertOrReplace(FocusMode(
                type = FocusModeType.GAMING.name,
                dndEnabled = true,
                allowedApps = "",
                allowedKeywords = "urgent,emergency,payment,OTP,verify",
                defaultAction = NotificationAction.BLOCK.name
            ))
            dao.insertOrReplace(FocusMode(
                type = FocusModeType.WORK.name,
                dndEnabled = false,
                allowedApps = "",
                allowedKeywords = "meeting,call,urgent,payment,OTP,bank",
                defaultAction = NotificationAction.SILENT.name
            ))
            dao.insertOrReplace(FocusMode(
                type = FocusModeType.SLEEP.name,
                dndEnabled = true,
                allowedApps = "",
                allowedKeywords = "emergency,urgent,alarm",
                defaultAction = NotificationAction.BLOCK.name
            ))
            dao.insertOrReplace(FocusMode(
                type = FocusModeType.CUSTOM.name,
                dndEnabled = false,
                allowedApps = "",
                allowedKeywords = "",
                defaultAction = NotificationAction.ALLOW.name
            ))
        }

        private suspend fun seedDefaultRules(dao: RuleDao) {
            val defaultKeywords = listOf("OTP", "bank", "urgent", "verify", "emergency", "payment", "password", "security")
            defaultKeywords.forEachIndexed { index, keyword ->
                dao.insert(Rule(
                    type = "KEYWORD",
                    value = keyword.lowercase(),
                    action = NotificationAction.ALLOW.name,
                    label = keyword,
                    isEnabled = true,
                    focusModes = "ALL"
                ))
            }
        }
    }
}
