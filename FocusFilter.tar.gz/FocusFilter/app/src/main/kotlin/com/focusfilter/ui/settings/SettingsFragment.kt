package com.focusfilter.ui.settings

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import com.focusfilter.FocusFilterApplication
import com.focusfilter.R
import com.focusfilter.databinding.FragmentSettingsBinding
import com.focusfilter.viewmodel.SettingsViewModel

class SettingsFragment : Fragment() {

    private var _binding: FragmentSettingsBinding? = null
    private val binding get() = _binding!!
    private val vm: SettingsViewModel by viewModels()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentSettingsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupPermissionButtons()
        setupSwitches()
        updatePermissionStatus()
    }

    override fun onResume() {
        super.onResume()
        updatePermissionStatus()
    }

    private fun setupPermissionButtons() {
        binding.btnGrantNotification.setOnClickListener {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        binding.btnGrantDnd.setOnClickListener {
            val app = requireContext().applicationContext as FocusFilterApplication
            app.dndManager.openDndSettings()
        }
    }

    private fun setupSwitches() {
        vm.startOnBoot.observe(viewLifecycleOwner) { binding.switchStartOnBoot.isChecked = it }
        binding.switchStartOnBoot.setOnCheckedChangeListener { _, checked -> vm.setStartOnBoot(checked) }
    }

    private fun updatePermissionStatus() {
        val notifGranted = isNotificationListenerEnabled()
        val dndGranted = (requireContext().applicationContext as FocusFilterApplication).dndManager.hasPermission

        val green = ContextCompat.getColor(requireContext(), R.color.accent_teal)
        val red = ContextCompat.getColor(requireContext(), R.color.accent_red)

        binding.tvNotifStatus.text = if (notifGranted) "Granted" else "Not granted"
        binding.tvNotifStatus.setTextColor(if (notifGranted) green else red)
        binding.btnGrantNotification.visibility = if (notifGranted) View.GONE else View.VISIBLE

        binding.tvDndStatus.text = if (dndGranted) "Granted" else "Not granted"
        binding.tvDndStatus.setTextColor(if (dndGranted) green else red)
        binding.btnGrantDnd.visibility = if (dndGranted) View.GONE else View.VISIBLE
    }

    private fun isNotificationListenerEnabled(): Boolean {
        val enabledListeners = Settings.Secure.getString(
            requireContext().contentResolver, "enabled_notification_listeners"
        ) ?: ""
        return enabledListeners.contains(requireContext().packageName)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
