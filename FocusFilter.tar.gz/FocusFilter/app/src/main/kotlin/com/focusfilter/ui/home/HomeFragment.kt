package com.focusfilter.ui.home

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.AnimationUtils
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import com.focusfilter.R
import com.focusfilter.databinding.FragmentHomeBinding
import com.focusfilter.model.FocusModeType
import com.focusfilter.viewmodel.HomeViewModel
import com.google.android.material.snackbar.Snackbar

class HomeFragment : Fragment() {

    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!
    private val vm: HomeViewModel by viewModels()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupModeCards()
        setupObservers()
        setupToggle()
    }

    private fun setupObservers() {
        vm.activeMode.observe(viewLifecycleOwner) { mode ->
            val isActive = mode != null && vm.isFocusEnabled
            updateStatusCard(isActive, mode?.type)
            updateModeCardHighlight(mode?.type)
            updateSummary()
        }

        vm.filteredTodayCount.observe(viewLifecycleOwner) { count ->
            binding.tvFilteredCount.text = count.toString()
        }

        vm.allowedTodayCount.observe(viewLifecycleOwner) { count ->
            binding.tvAllowedCount.text = count.toString()
        }

        vm.latestEntry.observe(viewLifecycleOwner) { entry ->
            if (entry != null) {
                binding.latestCard.visibility = View.VISIBLE
                binding.tvLatestApp.text = entry.appName
                binding.tvLatestAction.text = buildString {
                    append(entry.action.lowercase().replaceFirstChar { it.uppercase() })
                    append(" • ")
                    append(entry.classifierLabel.replaceFirstChar { it.uppercase() })
                }
                binding.tvLatestTime.text = formatTime(entry.timestamp)
            } else {
                binding.latestCard.visibility = View.GONE
            }
        }
    }

    private fun setupToggle() {
        binding.switchFocus.setOnCheckedChangeListener { _, checked ->
            if (checked) {
                val selected = getSelectedMode()
                if (selected == null) {
                    binding.switchFocus.isChecked = false
                    Snackbar.make(requireView(), "Select a focus mode first", Snackbar.LENGTH_SHORT).show()
                    return@setOnCheckedChangeListener
                }
                if (!isNotificationListenerEnabled()) {
                    binding.switchFocus.isChecked = false
                    Snackbar.make(requireView(), "Grant notification access first", Snackbar.LENGTH_LONG)
                        .setAction("Grant") {
                            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                        }.show()
                    return@setOnCheckedChangeListener
                }
                vm.activateMode(selected)
                animateStatusCard(true)
            } else {
                vm.deactivateFocus()
                animateStatusCard(false)
            }
        }
    }

    private fun setupModeCards() {
        binding.cardGaming.setOnClickListener { selectMode(FocusModeType.GAMING) }
        binding.cardWork.setOnClickListener { selectMode(FocusModeType.WORK) }
        binding.cardSleep.setOnClickListener { selectMode(FocusModeType.SLEEP) }
        binding.cardCustom.setOnClickListener { selectMode(FocusModeType.CUSTOM) }
    }

    private var selectedMode: FocusModeType? = null

    private fun selectMode(mode: FocusModeType) {
        selectedMode = mode
        updateModeCardHighlight(mode.name)
        if (vm.isFocusEnabled) {
            vm.activateMode(mode)
        }
    }

    private fun getSelectedMode(): FocusModeType? = selectedMode

    private fun updateModeCardHighlight(activeType: String?) {
        val accent = ContextCompat.getColor(requireContext(), R.color.accent_purple)
        val default = ContextCompat.getColor(requireContext(), R.color.divider)
        val alpha30 = 0x4D

        listOf(
            FocusModeType.GAMING to binding.cardGaming,
            FocusModeType.WORK to binding.cardWork,
            FocusModeType.SLEEP to binding.cardSleep,
            FocusModeType.CUSTOM to binding.cardCustom
        ).forEach { (mode, card) ->
            val isSelected = mode.name == activeType
            card.strokeColor = if (isSelected) accent else default
            card.strokeWidth = if (isSelected) resources.getDimensionPixelSize(R.dimen.card_stroke_selected) else 1
            if (isSelected && selectedMode == null) selectedMode = mode
        }
        binding.ivCheckGaming.visibility = if (activeType == FocusModeType.GAMING.name) View.VISIBLE else View.GONE
        binding.ivCheckWork.visibility = if (activeType == FocusModeType.WORK.name) View.VISIBLE else View.GONE
        binding.ivCheckSleep.visibility = if (activeType == FocusModeType.SLEEP.name) View.VISIBLE else View.GONE
        binding.ivCheckCustom.visibility = if (activeType == FocusModeType.CUSTOM.name) View.VISIBLE else View.GONE
    }

    private fun updateStatusCard(isActive: Boolean, modeType: String?) {
        binding.switchFocus.isChecked = isActive

        if (isActive) {
            val modeName = FocusModeType.values().find { it.name == modeType }?.displayName ?: "Focus Mode"
            binding.tvStatusTitle.text = getString(R.string.focus_mode_active)
            binding.tvModeName.text = modeName
            binding.tvProtectedMessage.text = getString(R.string.protected_message)
            binding.tvDndStatus.text = getString(R.string.dnd_on)
            binding.tvDndStatus.setTextColor(ContextCompat.getColor(requireContext(), R.color.dnd_on))
        } else {
            binding.tvStatusTitle.text = getString(R.string.focus_mode_inactive)
            binding.tvModeName.text = "No active mode"
            binding.tvProtectedMessage.text = getString(R.string.inactive_message)
            binding.tvDndStatus.text = getString(R.string.dnd_off)
            binding.tvDndStatus.setTextColor(ContextCompat.getColor(requireContext(), R.color.dnd_off))
        }
    }

    private fun updateSummary() {
        binding.tvFocusTime.text = vm.getFocusTimeFormatted()
    }

    private fun animateStatusCard(active: Boolean) {
        val anim = if (active) R.anim.scale_in else R.anim.fade_in
        binding.cardStatus.startAnimation(AnimationUtils.loadAnimation(requireContext(), anim))
    }

    private fun isNotificationListenerEnabled(): Boolean {
        val enabledListeners = Settings.Secure.getString(
            requireContext().contentResolver,
            "enabled_notification_listeners"
        ) ?: ""
        return enabledListeners.contains(requireContext().packageName)
    }

    private fun formatTime(ts: Long): String {
        val diff = System.currentTimeMillis() - ts
        val minutes = diff / 60000
        val hours = minutes / 60
        return when {
            minutes < 1 -> "Just now"
            minutes < 60 -> "${minutes}m ago"
            hours < 24 -> "${hours}h ago"
            else -> "Yesterday"
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
