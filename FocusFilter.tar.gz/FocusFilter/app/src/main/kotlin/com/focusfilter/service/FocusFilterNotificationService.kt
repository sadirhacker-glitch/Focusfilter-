package com.focusfilter.service

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import com.focusfilter.FocusFilterApplication
import com.focusfilter.data.db.entities.FilteredNotification
import com.focusfilter.model.FocusModeType
import com.focusfilter.model.NotificationAction
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.firstOrNull

class FocusFilterNotificationService : NotificationListenerService() {

    private val serviceScope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private val classifier: NotificationClassifier = SimpleClassifier()

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val app = applicationContext as FocusFilterApplication
        val prefs = app.preferencesManager

        if (!prefs.isFocusEnabled) return
        if (sbn.packageName == packageName) return

        val extras = sbn.notification?.extras ?: return
        val title = extras.getString("android.title") ?: ""
        val text = extras.getCharSequence("android.text")?.toString() ?: ""
        val combined = "$title $text"
        val appName = getAppName(sbn.packageName)
        val timestamp = sbn.postTime

        serviceScope.launch {
            val activeModeStr = prefs.activeModeType
            if (activeModeStr == FocusModeType.NONE.name) return@launch

            val rules = app.ruleRepository.getEnabledRules()
            val label = classifier.classify(combined)

            val action = resolveAction(
                packageName = sbn.packageName,
                title = title,
                text = text,
                label = label,
                rules = rules,
                activeModeStr = activeModeStr,
                app = app
            )

            if (action == NotificationAction.BLOCK || action == NotificationAction.HOLD ||
                action == NotificationAction.SILENT) {
                if (action == NotificationAction.BLOCK || action == NotificationAction.SILENT) {
                    cancelNotification(sbn.key)
                }
                val entry = FilteredNotification(
                    packageName = sbn.packageName,
                    appName = appName,
                    title = title,
                    text = text,
                    timestamp = timestamp,
                    action = action.name,
                    classifierLabel = label,
                    activeModeAtTime = activeModeStr
                )
                app.notificationRepository.insert(entry)
            } else {
                // ALLOW — log it but don't suppress
                val entry = FilteredNotification(
                    packageName = sbn.packageName,
                    appName = appName,
                    title = title,
                    text = text,
                    timestamp = timestamp,
                    action = NotificationAction.ALLOW.name,
                    classifierLabel = label,
                    activeModeAtTime = activeModeStr,
                    isRestored = true // mark as not held, so it won't show in inbox
                )
                app.notificationRepository.insert(entry)
            }
        }
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {}

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.cancel()
    }

    private suspend fun resolveAction(
        packageName: String,
        title: String,
        text: String,
        label: String,
        rules: List<com.focusfilter.data.db.entities.Rule>,
        activeModeStr: String,
        app: FocusFilterApplication
    ): NotificationAction {
        val combined = "$title $text".lowercase()

        // 1. Check VIP contact rules — always allow
        rules.filter { it.type == "VIP_CONTACT" && matchesModes(it.focusModes, activeModeStr) }
            .forEach { rule ->
                if (combined.contains(rule.value.lowercase())) {
                    return NotificationAction.ALLOW
                }
            }

        // 2. Check allowed apps
        rules.filter { it.type == "ALLOWED_APP" && matchesModes(it.focusModes, activeModeStr) }
            .forEach { rule ->
                if (packageName == rule.value || packageName.contains(rule.value)) {
                    return NotificationAction.valueOf(rule.action)
                }
            }

        // 3. Check keyword allow rules
        rules.filter { it.type == "KEYWORD" && matchesModes(it.focusModes, activeModeStr) }
            .forEach { rule ->
                if (combined.contains(rule.value.lowercase())) {
                    return NotificationAction.valueOf(rule.action)
                }
            }

        // 4. Check classifier label — OTP, emergency, payment always pass in any mode
        if (label in listOf("otp", "emergency", "security", "payment", "bank")) {
            return NotificationAction.ALLOW
        }

        // 5. Custom rules
        rules.filter { it.type == "CUSTOM" && matchesModes(it.focusModes, activeModeStr) }
            .forEach { rule ->
                if (combined.contains(rule.value.lowercase())) {
                    return NotificationAction.valueOf(rule.action)
                }
            }

        // 6. Check mode's allowed keywords
        val mode = app.focusModeRepository.getModeByType(activeModeStr)
        if (mode != null) {
            val modeKeywords = mode.allowedKeywords.split(",").filter { it.isNotBlank() }
            if (modeKeywords.any { combined.contains(it.lowercase()) }) {
                return NotificationAction.ALLOW
            }
            return NotificationAction.valueOf(mode.defaultAction)
        }

        return NotificationAction.BLOCK
    }

    private fun matchesModes(focusModes: String, activeMode: String): Boolean {
        return focusModes == "ALL" || focusModes.split(",").any { it.trim() == activeMode }
    }

    private fun getAppName(packageName: String): String {
        return try {
            val pm = applicationContext.packageManager
            val info = pm.getApplicationInfo(packageName, 0)
            pm.getApplicationLabel(info).toString()
        } catch (e: Exception) {
            packageName.substringAfterLast(".")
        }
    }
}
