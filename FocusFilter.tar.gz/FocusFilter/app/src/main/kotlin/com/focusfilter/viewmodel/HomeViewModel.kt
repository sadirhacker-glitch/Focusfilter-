package com.focusfilter.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.asLiveData
import androidx.lifecycle.viewModelScope
import com.focusfilter.FocusFilterApplication
import com.focusfilter.data.db.entities.FilteredNotification
import com.focusfilter.data.db.entities.FocusMode
import com.focusfilter.model.FocusModeType
import com.focusfilter.util.DndManager
import kotlinx.coroutines.launch
import java.util.Calendar

class HomeViewModel(application: Application) : AndroidViewModel(application) {

    private val app = application as FocusFilterApplication

    val activeMode: LiveData<FocusMode?> = app.focusModeRepository.getActiveMode().asLiveData()
    val isFocusEnabled: Boolean get() = app.preferencesManager.isFocusEnabled

    val filteredTodayCount: LiveData<Int> =
        app.notificationRepository.countFilteredToday(todayStart()).asLiveData()

    val allowedTodayCount: LiveData<Int> =
        app.notificationRepository.countAllowedToday(todayStart()).asLiveData()

    val latestEntry: LiveData<FilteredNotification?> =
        app.notificationRepository.getLatestEntry(todayStart()).asLiveData()

    fun activateMode(type: FocusModeType) {
        viewModelScope.launch {
            app.focusModeRepository.activateMode(type.name)
            app.preferencesManager.activeModeType = type.name
            app.preferencesManager.isFocusEnabled = true

            val mode = app.focusModeRepository.getModeByType(type.name)
            if (mode?.dndEnabled == true) {
                app.dndManager.enableDnd()
            } else {
                app.dndManager.disableDnd()
            }

            if (app.preferencesManager.focusStartTimestamp == 0L) {
                app.preferencesManager.focusStartTimestamp = System.currentTimeMillis()
            }
        }
    }

    fun deactivateFocus() {
        viewModelScope.launch {
            app.focusModeRepository.deactivateAll()
            app.preferencesManager.isFocusEnabled = false
            app.preferencesManager.activeModeType = FocusModeType.NONE.name
            app.dndManager.disableDnd()

            val start = app.preferencesManager.focusStartTimestamp
            if (start > 0L) {
                val elapsed = (System.currentTimeMillis() - start) / 60000L
                app.preferencesManager.totalFocusMinutesToday += elapsed
                app.preferencesManager.focusStartTimestamp = 0L
            }
        }
    }

    fun getFocusTimeFormatted(): String {
        var minutes = app.preferencesManager.totalFocusMinutesToday
        val start = app.preferencesManager.focusStartTimestamp
        if (start > 0L && app.preferencesManager.isFocusEnabled) {
            minutes += (System.currentTimeMillis() - start) / 60000L
        }
        val hours = minutes / 60
        val mins = minutes % 60
        return if (hours > 0) "${hours}h ${mins}m" else "${mins}m"
    }

    private fun todayStart(): Long {
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        return cal.timeInMillis
    }
}
