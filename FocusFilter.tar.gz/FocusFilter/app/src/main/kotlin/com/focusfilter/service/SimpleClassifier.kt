package com.focusfilter.service

/**
 * A simple keyword-based on-device classifier.
 * Entirely local — no network calls, no external SDKs.
 */
class SimpleClassifier : NotificationClassifier {

    override fun classify(notificationText: String): String {
        val lower = notificationText.lowercase()

        return when {
            lower.containsAny("otp", "one-time", "one time", "verification code", "auth code") -> "otp"
            lower.containsAny("payment", "paid", "transaction", "credited", "debited", "transfer") -> "payment"
            lower.containsAny("bank", "account", "balance", "statement", "loan", "emi") -> "bank"
            lower.containsAny("emergency", "urgent", "critical", "immediately", "asap") -> "emergency"
            lower.containsAny("password", "security", "verify", "confirm", "suspicious") -> "security"
            lower.containsAny("offer", "discount", "sale", "% off", "deal", "limited time", "coupon", "promo") -> "promo"
            lower.containsAny("liked", "commented", "followed", "mention", "tagged", "story", "reacted") -> "social"
            lower.containsAny("spam", "unsubscribe", "click here", "win", "winner", "prize", "free") -> "spam"
            lower.containsAny("meeting", "call scheduled", "reminder", "task", "due", "deadline") -> "important"
            else -> "unknown"
        }
    }

    private fun String.containsAny(vararg keywords: String): Boolean =
        keywords.any { this.contains(it) }
}
