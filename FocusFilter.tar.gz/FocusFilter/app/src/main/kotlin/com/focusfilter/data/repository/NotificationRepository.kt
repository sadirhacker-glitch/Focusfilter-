package com.focusfilter.data.repository

import com.focusfilter.data.db.dao.FilteredNotificationDao
import com.focusfilter.data.db.entities.FilteredNotification
import kotlinx.coroutines.flow.Flow

class NotificationRepository(private val dao: FilteredNotificationDao) {

    fun getActiveFiltered(): Flow<List<FilteredNotification>> = dao.getActiveFiltered()

    fun getRecentLogs(limit: Int = 50): Flow<List<FilteredNotification>> = dao.getRecentLogs(limit)

    fun countFilteredToday(since: Long): Flow<Int> = dao.countFilteredSince(since)

    fun countAllowedToday(since: Long): Flow<Int> = dao.countAllowedSince(since)

    fun getLatestEntry(since: Long): Flow<FilteredNotification?> = dao.getLatestEntry(since)

    suspend fun insert(notification: FilteredNotification) = dao.insert(notification)

    suspend fun markRestored(id: Long) = dao.markRestored(id)

    suspend fun deleteById(id: Long) = dao.deleteById(id)

    suspend fun clearAll() = dao.clearAll()
}
