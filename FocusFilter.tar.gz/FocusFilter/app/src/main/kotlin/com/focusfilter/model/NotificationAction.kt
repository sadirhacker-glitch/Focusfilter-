package com.focusfilter.model

enum class NotificationAction(val label: String) {
    ALLOW("Allow"),
    BLOCK("Block"),
    SILENT("Silent"),
    HOLD("Hold")
}
