package com.focusfilter.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.focusfilter.R
import com.focusfilter.data.db.entities.FilteredNotification
import com.focusfilter.model.NotificationAction
import java.text.SimpleDateFormat
import java.util.*
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView

class NotificationAdapter(
    private val onRestore: (FilteredNotification) -> Unit,
    private val onDelete: (FilteredNotification) -> Unit
) : ListAdapter<FilteredNotification, NotificationAdapter.ViewHolder>(DIFF) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_notification, parent, false)
        return ViewHolder(v)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val card: MaterialCardView = itemView.findViewById(R.id.card)
        private val tvAppName: TextView = itemView.findViewById(R.id.tvAppName)
        private val tvTitle: TextView = itemView.findViewById(R.id.tvTitle)
        private val tvText: TextView = itemView.findViewById(R.id.tvText)
        private val tvTime: TextView = itemView.findViewById(R.id.tvTime)
        private val tvAction: TextView = itemView.findViewById(R.id.tvAction)
        private val tvLabel: TextView = itemView.findViewById(R.id.tvLabel)
        private val expandedGroup: View = itemView.findViewById(R.id.expandedGroup)
        private val btnRestore: MaterialButton = itemView.findViewById(R.id.btnRestore)
        private val btnDelete: MaterialButton = itemView.findViewById(R.id.btnDelete)

        fun bind(item: FilteredNotification) {
            tvAppName.text = item.appName
            tvTitle.text = item.title.ifBlank { item.appName }
            tvText.text = item.text
            tvTime.text = formatTime(item.timestamp)
            tvAction.text = item.action
            tvLabel.text = item.classifierLabel

            val ctx = itemView.context
            val actionColor = when (item.action) {
                NotificationAction.BLOCK.name -> ContextCompat.getColor(ctx, R.color.accent_red)
                NotificationAction.HOLD.name -> ContextCompat.getColor(ctx, R.color.accent_amber)
                NotificationAction.SILENT.name -> ContextCompat.getColor(ctx, R.color.text_secondary)
                else -> ContextCompat.getColor(ctx, R.color.accent_teal)
            }
            tvAction.setTextColor(actionColor)

            var expanded = false
            card.setOnClickListener {
                expanded = !expanded
                expandedGroup.visibility = if (expanded) View.VISIBLE else View.GONE
            }

            btnRestore.setOnClickListener { onRestore(item) }
            btnDelete.setOnClickListener { onDelete(item) }
        }

        private fun formatTime(ts: Long): String {
            val diff = System.currentTimeMillis() - ts
            val minutes = diff / 60000
            val hours = minutes / 60
            return when {
                minutes < 1 -> "Just now"
                minutes < 60 -> "${minutes}m ago"
                hours < 24 -> "${hours}h ago"
                else -> SimpleDateFormat("MMM d", Locale.getDefault()).format(Date(ts))
            }
        }
    }

    companion object {
        val DIFF = object : DiffUtil.ItemCallback<FilteredNotification>() {
            override fun areItemsTheSame(a: FilteredNotification, b: FilteredNotification) = a.id == b.id
            override fun areContentsTheSame(a: FilteredNotification, b: FilteredNotification) = a == b
        }
    }
}
