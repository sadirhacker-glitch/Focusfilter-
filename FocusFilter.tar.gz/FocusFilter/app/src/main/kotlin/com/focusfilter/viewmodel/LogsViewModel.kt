package com.focusfilter.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.asLiveData
import com.focusfilter.FocusFilterApplication
import com.focusfilter.data.db.entities.FilteredNotification

class LogsViewModel(application: Application) : AndroidViewModel(application) {

    private val app = application as FocusFilterApplication

    val recentLogs: LiveData<List<FilteredNotification>> =
        app.notificationRepository.getRecentLogs(100).asLiveData()
}
