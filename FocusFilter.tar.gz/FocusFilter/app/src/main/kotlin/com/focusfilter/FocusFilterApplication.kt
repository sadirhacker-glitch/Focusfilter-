package com.focusfilter

import android.app.Application
import com.focusfilter.data.db.AppDatabase
import com.focusfilter.data.repository.FocusModeRepository
import com.focusfilter.data.repository.NotificationRepository
import com.focusfilter.data.repository.RuleRepository
import com.focusfilter.util.DndManager
import com.focusfilter.util.PreferencesManager

class FocusFilterApplication : Application() {

    val database by lazy { AppDatabase.getInstance(this) }

    val notificationRepository by lazy {
        NotificationRepository(database.filteredNotificationDao())
    }
    val focusModeRepository by lazy {
        FocusModeRepository(database.focusModeDao())
    }
    val ruleRepository by lazy {
        RuleRepository(database.ruleDao())
    }

    val preferencesManager by lazy { PreferencesManager(this) }
    val dndManager by lazy { DndManager(this) }
}
