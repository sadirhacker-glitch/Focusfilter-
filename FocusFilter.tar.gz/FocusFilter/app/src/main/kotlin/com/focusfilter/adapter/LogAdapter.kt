package com.focusfilter.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.focusfilter.R
import com.focusfilter.data.db.entities.FilteredNotification
import com.focusfilter.model.NotificationAction
import java.text.SimpleDateFormat
import java.util.*

class LogAdapter : ListAdapter<FilteredNotification, LogAdapter.ViewHolder>(DIFF) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_log, parent, false)
        return ViewHolder(v)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val tvAppName: TextView = itemView.findViewById(R.id.tvAppName)
        private val tvTitle: TextView = itemView.findViewById(R.id.tvTitle)
        private val tvTime: TextView = itemView.findViewById(R.id.tvTime)
        private val tvAction: TextView = itemView.findViewById(R.id.tvAction)
        private val tvLabel: TextView = itemView.findViewById(R.id.tvLabel)

        fun bind(item: FilteredNotification) {
            tvAppName.text = item.appName
            tvTitle.text = item.title.ifBlank { item.text }.take(60)
            tvTime.text = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(item.timestamp))
            tvAction.text = item.action
            tvLabel.text = item.classifierLabel

            val ctx = itemView.context
            val actionColor = when (item.action) {
                NotificationAction.BLOCK.name -> ContextCompat.getColor(ctx, R.color.accent_red)
                NotificationAction.HOLD.name -> ContextCompat.getColor(ctx, R.color.accent_amber)
                NotificationAction.SILENT.name -> ContextCompat.getColor(ctx, R.color.text_secondary)
                else -> ContextCompat.getColor(ctx, R.color.accent_teal)
            }
            tvAction.setTextColor(actionColor)
        }
    }

    companion object {
        val DIFF = object : DiffUtil.ItemCallback<FilteredNotification>() {
            override fun areItemsTheSame(a: FilteredNotification, b: FilteredNotification) = a.id == b.id
            override fun areContentsTheSame(a: FilteredNotification, b: FilteredNotification) = a == b
        }
    }
}
