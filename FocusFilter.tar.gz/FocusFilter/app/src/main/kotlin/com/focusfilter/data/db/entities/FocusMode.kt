package com.focusfilter.data.db.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "focus_modes")
data class FocusMode(
    @PrimaryKey val type: String, // FocusModeType name
    val isActive: Boolean = false,
    val dndEnabled: Boolean = false,
    val allowedApps: String = "",      // comma-separated package names
    val allowedContacts: String = "",  // comma-separated contact names/numbers
    val allowedKeywords: String = "",  // comma-separated keywords
    val blockedKeywords: String = "",  // comma-separated keywords to block
    val defaultAction: String = "BLOCK" // default action for unmatched notifications
)
