package com.focusfilter.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.focusfilter.FocusFilterApplication
import kotlinx.coroutines.launch

class SettingsViewModel(application: Application) : AndroidViewModel(application) {

    private val app = application as FocusFilterApplication

    val startOnBoot = MutableLiveData(app.preferencesManager.startOnBoot)

    fun setStartOnBoot(enabled: Boolean) {
        app.preferencesManager.startOnBoot = enabled
        startOnBoot.value = enabled
    }
}
