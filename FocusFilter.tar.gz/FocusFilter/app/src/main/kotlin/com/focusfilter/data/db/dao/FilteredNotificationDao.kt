package com.focusfilter.data.db.dao

import androidx.room.*
import com.focusfilter.data.db.entities.FilteredNotification
import kotlinx.coroutines.flow.Flow

@Dao
interface FilteredNotificationDao {

    @Query("SELECT * FROM filtered_notifications WHERE isRestored = 0 ORDER BY timestamp DESC")
    fun getActiveFiltered(): Flow<List<FilteredNotification>>

    @Query("SELECT * FROM filtered_notifications ORDER BY timestamp DESC LIMIT :limit")
    fun getRecentLogs(limit: Int = 50): Flow<List<FilteredNotification>>

    @Query("SELECT COUNT(*) FROM filtered_notifications WHERE action IN ('BLOCK','HOLD') AND timestamp > :since")
    fun countFilteredSince(since: Long): Flow<Int>

    @Query("SELECT COUNT(*) FROM filtered_notifications WHERE action = 'ALLOW' AND timestamp > :since")
    fun countAllowedSince(since: Long): Flow<Int>

    @Query("SELECT * FROM filtered_notifications WHERE timestamp > :since ORDER BY timestamp DESC LIMIT 1")
    fun getLatestEntry(since: Long): Flow<FilteredNotification?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(notification: FilteredNotification)

    @Update
    suspend fun update(notification: FilteredNotification)

    @Query("UPDATE filtered_notifications SET isRestored = 1 WHERE id = :id")
    suspend fun markRestored(id: Long)

    @Query("DELETE FROM filtered_notifications WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM filtered_notifications WHERE isRestored = 1")
    suspend fun clearRestored()

    @Query("DELETE FROM filtered_notifications")
    suspend fun clearAll()
}
