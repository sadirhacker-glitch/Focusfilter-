package com.focusfilter.data.db.entities

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.focusfilter.model.NotificationAction

@Entity(tableName = "filtered_notifications")
data class FilteredNotification(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val packageName: String,
    val appName: String,
    val title: String,
    val text: String,
    val timestamp: Long,
    val action: String,           // NotificationAction name
    val classifierLabel: String,  // e.g. "otp", "spam", "important"
    val activeModeAtTime: String, // FocusModeType name
    val isRead: Boolean = false,
    val isRestored: Boolean = false
)
