package com.focusfilter.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.asLiveData
import androidx.lifecycle.viewModelScope
import com.focusfilter.FocusFilterApplication
import com.focusfilter.data.db.entities.FilteredNotification
import kotlinx.coroutines.launch

class InboxViewModel(application: Application) : AndroidViewModel(application) {

    private val app = application as FocusFilterApplication

    val filteredNotifications: LiveData<List<FilteredNotification>> =
        app.notificationRepository.getActiveFiltered().asLiveData()

    fun restore(id: Long) {
        viewModelScope.launch { app.notificationRepository.markRestored(id) }
    }

    fun delete(id: Long) {
        viewModelScope.launch { app.notificationRepository.deleteById(id) }
    }

    fun clearAll() {
        viewModelScope.launch { app.notificationRepository.clearAll() }
    }
}
